var app = angular.module("apps", []);
app
		.controller(
				"ctrl",
				function($scope) {
					$scope.mailformat = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
					$scope.mobile = /^(\+?(\d{1}|\d{2}|\d{3})[- ]?)?\d{3}[- ]?\d{3}[- ]?\d{4}$/;
					$scope.submit = function() {

						$scope.submitted = true;
					}

					$scope.hasError = function(field, validation) {
						if (validation) {
							return ($scope.register[field].$dirty && $scope.register[field].$error[validation])
									|| ($scope.submitted && $scope.register[field].$error[validation]);
						}
						return ($scope.register[field].$dirty && $scope.register[field].$invalid)
								|| ($scope.submitted && $scope.register[field].$invalid);
					};
				});
